print ('year_loop')
from month_loop import month_loop
def year_loop():
    for year in range (0,100):
        leap_yr = False
        print('if year before')
        if year %4 == 0:
            print('if year in')
            leap_yr = True
        print('if year after')
        month_loop(year,leap_yr)
