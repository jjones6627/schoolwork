from year_loop import year_loop
def main():
    print(f'{"Palindrome Date":<15}')
    print(f'{"--------------":<15}')
    year_loop()
if __name__== '__main__':
    main()
