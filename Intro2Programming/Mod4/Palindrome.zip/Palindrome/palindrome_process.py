#Lincoln Warner,Christian Alfaro,Victor Kislov,Kleidi Mick 
#Extra credit module 5
#palindrome process
#import palindrome_main
#import year_loop
#import month_loop
print('palindrome_process')


    
def palindrome_process(year,month,day,date): #above statement receives year month day and date from the day_loop function
    
    
    number=date
    temp=number
    reverse_num=0
    while(number)>0:
        digit=number%10  #extract last digit
        reverse_num=reverse_num*10 + digit #append digit, reversed
        number=number//10
        #floor divide number leave out the last digit
    #compare reversed number to original number
    if(temp==reverse_num):
        print(f'{month}/{day}/{year}')















    
