print('day_loop')
from palindrome_process import palindrome_process

def day_loop(year,month,last_day):
    for day in range(1,last_day+1):
        if year >9:
            if day >9:
                date = month*10000 + day*100 + year
            else:
                date = month*1000 + day*100 + year
        else:
            if day >9:
                date = month*1000 + day*10 + year
            else:
                date = month*100 + day*10 + year
        palindrome_process(year,month,day,date)
            
