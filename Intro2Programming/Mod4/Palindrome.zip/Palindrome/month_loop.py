print('month_loop')
from day_loop import day_loop
def month_loop(year,leap_yr):
    for month in range(1,13):
        if month == 1:
            last_day = 31
        elif month == 2:
            if leap_yr:
                last_day = 29
            else:
                last_day = 28
        elif month == 3:
            last_day = 31
        elif month == 4:
            last_day = 30
        elif month == 5:
            last_day = 31
        elif month == 6:
            last_day = 30
        elif month == 7:
            last_day = 31
        elif month == 8:
            last_day = 31
        elif month == 9:
            last_day = 30
        elif month == 10:
            last_day = 31
        elif month == 11:
            last_day = 30
        elif month == 12:
            last_day = 31
        day_loop(year,month,last_day)
