# This program demonstrates how the range
# function can be used with a for loop.

# Print a message five times.
for x in range(5):
    print('Hello world!')

