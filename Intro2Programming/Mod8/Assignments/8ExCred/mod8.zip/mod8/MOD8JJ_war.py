
import random

#first key

def main():
    deck = create_deck()
    print(f'deck = {deck}' )
    player1_cards = deal_cards(deck)
    print(f'player1_cards = {player1_cards}')
    player2_cards = deal_cards(deck)
    print(f'player2_cards = {player2_cards}')
    print(f'deck = {deck}')
    hold_cards = {}
    while len(player1_cards) != 0 and len(player2_cards) != 0 and\
      "" == input('Press enter or retrurn to play hand'):
        rand_player1_card = random.choice(list(player1_cards))
        rand_player1_val=player1_cards.pop(rand_player1_card,'element not found')
        hold_cards[rand_player1_card] = rand_player1_val
        print(f"player's 1 card: {rand_player1_card} total cards for player 1\
{len(player1_cards)}")
        rand_player2_card = random.choice(list(player2_cards))
        rand_player2_val=player2_cards.pop(rand_player2_card,'element not found')
        hold_cards[rand_player2_card] = rand_player2_val
        print(f"player's 1 card: {rand_player2_card} total cards for player 2\
{len(player2_cards)}")    
    
