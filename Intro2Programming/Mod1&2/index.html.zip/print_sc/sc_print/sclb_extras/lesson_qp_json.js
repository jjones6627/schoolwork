lesson_qp_format_json = "{}";
