
# print4.py
# The sep operator separates print items by
# a string that you specify inside a print().
# For fun, we specify ' ** ' as the separator.

def main():

    print('Hello','SPC','Student',sep=' *** ')
               
main()


