
# print1.py
# A space is printed between items that are
# separated by commas in a print() statement

def main():
    item = 'pencils'
    qty = 12
    price = 0.39
    ext_price = qty * price
    print('Buy',qty,'hammers @ $',price,'for $',ext_price)
               
main()

