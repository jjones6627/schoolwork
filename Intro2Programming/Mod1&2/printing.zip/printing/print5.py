
# print5.py
# The end operator suppresses print's newline
# and supplies a specified string instead.
# Here two prints end with a space. A silly
# program but it shows how end works.

def main():

    name1 = 'Guido'
    name2 = 'Van'
    name3 = 'Rossum'
    print(name1,end=' ')
    print(name2,end=' ')
    print(name3)
    
main()


