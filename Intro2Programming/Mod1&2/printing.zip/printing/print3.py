
# print3.py
# The sep operator separates print items by
# a string that you specify inside a print().
# Spaces inside the strings fixes the output.

def main():
    item = 'pencils'
    qty = 12
    price = 0.39
    ext_price = qty * price
    print('Buy ',qty,' hammers @ $',price,' for $',ext_price,sep='')
               
main()


