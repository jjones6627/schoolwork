# ascii_name.py
# chr(n) returns the ASCII character for integer n
# See Appendix C in the textbook

def main():

    ascii = {}  # an empty dictionary
    
    # loop through all upper and lower case alphabet
    # to create a dictionary of characters and their integers
    
    for n in range(65,123):
        # add a new dictionary key:value pair
        ascii[chr(n)] = n
        
    # crudely dump the dictionary to output    
    print(ascii)

    name = input('Your name? ')
    
    print(f'Here are the ASCII integers for {name}')
    for ch in name:
        print(ascii[ch], end = ' ')
    
    

if __name__ == '__main__':
    main()




    
