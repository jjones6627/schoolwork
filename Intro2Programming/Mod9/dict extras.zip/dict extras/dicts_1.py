# dicts_1.py
# A dictionary is a collection of key:value pairs.
# Values are retrieved by their keys.

def main():

    branches = {'Executive':'President',
                'Legislative':'Congress',
                'Judicial':'Supreme Court'}
    for k in branches:
        print('The',k,'branch:',branches[k])

    # a dictionary is an object.
    # it has functions called methods
    
    print('\nUsing the items() method')
    for k,v in branches.items():
        print('The',v,'is the',k,'branch')
    
if __name__ == '__main__':
    main()
