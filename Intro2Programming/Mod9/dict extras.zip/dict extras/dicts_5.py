# dicts_5.py
# awesome dictionary comprehensions. PAGE 490
# you can make a dictionary with code inside {}
# General Form: {result_expression iteration_expression}

def main():

    # NOTE: chr(n) returns the ASCII/Unicode character for n
    # a dictionary of ints and their Unicode characters
    # See Appendix C in textbook to verify
    
    print('Start of lower case alphabet...')
    
    # make it with a dictionary comprehension
    chars = {ch : chr(ch) for ch in range(97,102)}
    print(chars)

    # make a dictionary from a list with a dictionary comprehension
    pals = ['Penny','Al','Fred','Benny','Ann','Valerie']
    name_len = {name:len(name) for name in pals}
    
    print('My friends...')
    for k in name_len:
        print(f"{k}'s name contains {name_len[k]} characters")

if __name__ == '__main__':
    main()
