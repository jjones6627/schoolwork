# dicts_6.py
# awesome dictionary comprehensions with if clause. PAGE 492
# General Form: {result_expression iteration_expression if_clause}

def main():

    # example: square roots of numbers ending in 4 between 10 and 100
    roots4 = {x : x ** (0.5) for x in range(10,101) if x % 10 == 4}

    col_1 = 'NUMBER'
    col_2 = 'SQ.ROOT'
    print(f'{col_1:<8}{col_2:>8}')
    
    for k,v in roots4.items():
        print(f'{k:<8d}{v:>8.5f}')

if __name__ == '__main__':
    main()
