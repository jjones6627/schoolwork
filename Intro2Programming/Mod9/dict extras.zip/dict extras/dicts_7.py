# dicts_7.py
# more dictionary methods. PAGE 475.
def main():

    grades = {'test1':90,'test2':80,'test3':84,'test4':88}
    print(grades)
    # get just the keys or just the values
    ks = grades.keys()
    vs = grades.values()
    print(ks)
    print(vs)

    # use get method
    test = input('Enter test name ')
    if test in grades:
        score = grades.get(test)
        print(f'Your {test} grade was {score}')
    else:
        print(f'Test {test} does not exist')
    
    # pop() nethod to remove and return a pair 
    gone = grades.pop('test2')
    print(f'{gone} was removed')
    print(grades)

    grades.clear()
    print(grades)  # dictionary is now empty

if __name__ == '__main__':
    main()
