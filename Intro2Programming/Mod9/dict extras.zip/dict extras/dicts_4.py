# dicts_4.py
# some dictionary skills
# chr(n) returns the ASCII character for integer n

def main():

    mydict = {}  # an empty dictionary

    # adding to the dictionary
    for n in range(65,70):
        mydict[n] = chr(n)
    print(mydict)

    # delete an element if key is found
    if 67 in mydict:
        del mydict[67]
    print(mydict)

    # report size of dictionary
    sz = len(mydict)
    print(f'mydict size is now {sz} elements')

    # one way to see the keys
    for k in mydict:
        print(k, end = ' ')

    # delete a dictionary with del
    del mydict
    print('\nDictionary was deleted')
    
if __name__ == '__main__':
    main()
