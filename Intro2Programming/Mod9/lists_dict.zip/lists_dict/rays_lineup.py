# rays_lineup.py
# dictionary keys are batting order
# each dictionary value is a list of name and position

def main():

    print('Rays Starting Lineup\n')
    rays = {1:['Arozarena','LF'],
            2:['Choi','1B'],
            3:['Cruz','DH'],
            4:['Meadows','RF'],
            5:['Diaz','3B'],
            6:['Franco','SS'],
            7:['Wendell','2B'],
            8:['Kiermaier','CF'],
            9:['Zunino','C']            
           }

    for k in rays:
        print(f'Batting {k}, {rays[k][1]} {rays[k][0]}')

    print('\n---Substitutions--- New Rays Lineup\n')

    # subs for catcher and second base

    rays[9] = ['Mejia','C']
    rays[7] = ['Lowe','2B']

    for k,v in rays.items():
        print(f'Batting {k}, {v[1]} {v[0]}')

if __name__ == '__main__':
    main()




    
