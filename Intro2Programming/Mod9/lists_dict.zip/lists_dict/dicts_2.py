# dicts_2.py
# Keys must be immutable types. Values can be any type.
# For example, the values might be lists.

def main():
    
    grades = {'math':[80,92,75],
              'chem':[88,94],
              'comp':[78,86,82,94],
              'ethics':[92,87,95]
             }

    for k,v in grades.items(): 
        print(k,'tests',end=': ')
        # now loop throught the list
        for t in v:   
            print(t,end=' ')
        # now get average for course    
        avg = sum(v) / len(v) / 100
        print(f'\nAverage: {avg:.1%}')
        print()
    
main()
