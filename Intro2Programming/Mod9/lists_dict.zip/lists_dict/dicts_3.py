# dicts_3.py
# a dictionary with integer keys
# NOTE: the values for keys can be lists

def main():

    age_grps = {18:['Penny','Lenny'],
                19:['Benny','Jenny','Kenny'],
                20:['Denny']
               }

    print('Age groups')
    for k in age_grps:
        print('Age',k,age_grps[k])

    print('\nBetter output processing...')
    for k in age_grps:
        print(f'Age {k}:', end = ' ')
        for name in age_grps[k]:
            print(name, end = ' ')
        print()

    print('\nOr you can process with items()...')
    for k,v in age_grps.items():
        print(f'Age {k}:', end = ' ')
        for name in v:
            print(name, end = ' ')
        print()

    jenny = age_grps[19][1]   # another way to access a list element
    print(f'\n{jenny} is 19')
    
main()
