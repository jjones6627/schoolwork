#John Jones COP-1000  #927
#Collaboration: I worked alone.

#Mod 6 pre-assignment 1

#

def main ():

    friends_file = open('friends.txt', 'w')

    name = input('Enter the first name of friend or Enter to quit ')
        
    while name != '':
        
        age = input('Enter age (integer) of this friend')

        friends_file.write(name + '\n')
        friends_file.write(age + '\n')
        
        name = input('Enter the first name of friend or Enter to quit ')

    friends_file.close()

    print('File was created')

        
if __name__ == '__main__':    

    main()

