#John Jones COP-1000  #927
#Collaboration: I worked alone.

#Mod 6 pre-assignment 2

#

def main ():

    friends_file = open('friends.txt', 'r')

    line = friends_file.readline()
    
    line_num = 1
    accum = 0
    age_count = 0
        
    while line != '':

        if line_num % 2 != 0:
            name = line.rstrip('\n')
             
        else: 
            age = line.rstrip('\n')
            accum = accum + int(age)
            age_count = age_count+1
            print(f'My friend {name} is {age}')

        line_num = line_num+1
        
        line = friends_file.readline()    
        
    friends_file.close()

    average_age = accum / age_count

    print(f'Average age of friends is {average_age:.1f}')

        
if __name__ == '__main__':    

    main()

