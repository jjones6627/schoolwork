# gpa_calc.py
# read gpa.txt and generate this table to find the GPA
# Points for letter grades A = 4, B = 3, C = 2, D = 1, F = 0
# Quality Points = hours * points
# Required output is below.
'''
COURSE          HOURS  GRADE  POINTS  Q POINTS 

Chemistry         3      B      3        9     
Programming       3      C      2        6     
Calculus          4      A      4        16    
Speech            2      A      4        8     
Ethics            3      B      3        9     
Physics           4      B      3        12    
----------------------------------------------
                 19                      60
GPA is 3.158    
'''

def main():

    f = open('gpa.txt','r')
    

if __name__ == '__main__':
    main()
        

    
