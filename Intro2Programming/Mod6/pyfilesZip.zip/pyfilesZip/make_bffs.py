#make_bffs.py - writes STRINGS to file

def main():
    # open bffs.txt with "handle" bffs in write mode
    bffs = open('bffs.txt','w')
    # write bff names to file, each on its own line
    bffs.write('Ricky' + '\n')
    bffs.write('Vicky' + '\n')
    bffs.write('Micky' + '\n')
    bffs.write('Nicky' + '\n')
    # close file
    bffs.close()
    print('File was created') # report success 

main()
