# read_bffs3.py - also reads STRINGS from file
# but uses a WHILE loop to step through the file
# and also strips out \n to prevent blank lines

def main():
    # open bffs.txt with "handle" bffs in READ mode
    bffs = open('bffs.txt','r')
    # read first line (priming read) into var. line
    line = bffs.readline()  
    # start loop to cycle until end of file
    while line != '':
        # keep cycling until line is empty
        bff = line.rstrip('\n') # remove newline
        print(bff) # print bff variable
        # ATTEMPT to read another line
        line = bffs.readline() # (continuation read)   
    # close file
    bffs.close()
    print('Reached End of File') # notice to user

main()
