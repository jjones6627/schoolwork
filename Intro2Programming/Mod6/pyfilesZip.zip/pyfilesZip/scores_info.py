
# scores_info.py - reads NUMBERS from file but
# also computes average and highest score.

def main():
    # open scores.txt as mytests in READ mode
    mytests = open('scores.txt','r')
    count = 0 # COUNTER (maybe # of scores is unknown)
    high = 0 # variable for highest score
    total = 0 # ACCUMULATOR for scores
    print('Your Scores and Summary') # BEFORE loop
    # start a for loop that will read each line
    # one-by-one, into a variable named line.
    for line in mytests:
        score = int(line) # convert from string
        print(score)
        count += 1      # INCREMENT count
        total += score  # ACCUMULATE scores
        if score > high:
            high = score  # found new high score

    # next statements are AFTER loop ends, NOT in loop
    mytests.close() # close file
    print('Average:',format(total / count,'.1f'))
    print('Highest score:',high)

main()


