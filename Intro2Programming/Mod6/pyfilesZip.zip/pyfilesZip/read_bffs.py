# read_bffs.py - reads STRINGS from file
# uses a FOR loop to step through the file
# ISSUE: runs okay, but prints blank lines

def main():
    # open bffs.txt with "handle" bffs in READ mode
    bffs = open('bffs.txt','r')
    # start a loop to read each line in bffs.txt
    # each line will be assigned to variable bff
    for bff in bffs:
        print(bff) # print bff variable
    # close file
    bffs.close()
    print('Reached End of File') # notice to user

main()
