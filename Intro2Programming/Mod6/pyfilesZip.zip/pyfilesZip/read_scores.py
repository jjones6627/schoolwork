
# read_scores.py - reads NUMBERS from file.
# NOTE: ALL file input/output uses STRINGS.
# int() converts strings back to integers  

def main():
    # open scores.txt as mytests in READ mode
    mytests = open('scores.txt','r')
    print('Your Scores') # heading BEFORE loop
    # start a for loop that will read each line
    # one-by-one, into a variable named line.
    for line in mytests:
        # print(line) # NO! Prints blank lines.
        # convert to integer (\n NOT an ISSUE)
        score = int(line) 
        print(score)  

    mytests.close() # close file
    print('End of file (EOF)') # notice 

main()
