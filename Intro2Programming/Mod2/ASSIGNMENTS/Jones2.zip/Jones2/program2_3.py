#How m,any widgets do you want? ==> 30000
#
#R E C E I P T
#
#widgets' base cost : $749,700.00 (30,000 @ $24.99)
#S&H : 30,000.00
#Tax : $52,479.00
#
#Total : $832,179.00
